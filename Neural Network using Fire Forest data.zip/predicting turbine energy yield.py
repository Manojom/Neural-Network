#!/usr/bin/env python
# coding: utf-8

# In[21]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression


# In[2]:


### Reading Data

data = pd.read_csv("C:\\Users\\Admin\\Downloads\\gas_turbines (1).csv")
data.head()


# In[6]:


####Giving the columns self-explanatory names

data.columns = ["Temperature","Compressor discharge pressure","Turbine after temperature","Exhaust_Vaccum", "Ambient_Pressure", "Relative_Humidity", "Energy_Output","Ambient_Humidity","Nitrogen oxides","Carbon monoxide","Turbine energy yield"]
data.head()


# In[8]:


data.isnull().sum()

# We can see that the data contains no null values.


# In[10]:


####Checking the relation between columns with Energy Output.
data.corr()["Energy_Output"]


# In[14]:


# Plotting the columns against the Energy Output.

for col in data.columns[:len(data.columns)-1]:
    plt.scatter(data[col], data["Energy_Output"], color="orange")
    plt.ylabel("Energy Ouput")
    plt.xlabel(col)
    plt.show()


# In[18]:


####Fitting Our Model and Predicting Models

# Randomizing the rows.

X = np.random.permutation(data.index)
data = data.reindex(X)


# In[20]:


###Creating test and train dataframes

A = int(len(data)*0.8)

test = data[:A]
train = data[A:]


# In[24]:


####Fitting out model on training data and making training predictions
cols = data.columns.drop("Energy_Output")

reg = LinearRegression()

reg.fit(train[cols], train["Energy_Output"])

predictions_train = reg.predict(train[cols])

rmse = (np.mean((predictions_train - train["Energy_Output"])**2))**0.5
rmse


# In[26]:


##Making Test Predictions

predictions_test = reg.predict(test[cols])

rmse = (np.mean((predictions_test - test["Energy_Output"])**2))**0.5
rmse


# In[28]:


# Making Test Predictions

predictions_test


# In[30]:


#### Reducing Error by Decision Tree Regressor

from sklearn.tree import DecisionTreeRegressor

reg = DecisionTreeRegressor(min_samples_leaf=2)

reg.fit(train[cols], train["Energy_Output"])

predictions_DT = reg.predict(test[cols])

rmse_DT = (np.mean(predictions_DT - test["Energy_Output"])**2)**0.5
rmse_DT


# In[31]:


####This shows that Decision Tree Regressor reduces our error greatly.
##Making Predictions.

predictions_DT

